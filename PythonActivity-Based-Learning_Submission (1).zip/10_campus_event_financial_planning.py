# Python Activity-Based Learning
# Case Study 10: Campus Event Financial Planning
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

venue = float(input("Venue cost: "))
equipment = float(input("Equipment cost: "))
catering = float(input("Catering cost: "))
transport = float(input("Transport cost: "))
certificates = float(input("Certificate cost: "))
sponsorship = float(input("Sponsorship received: "))
fee = float(input("Registration fee per participant: "))
values = [venue, equipment, catering, transport, certificates, sponsorship, fee]
if min(values) < 0:
    print("Invalid input: values cannot be negative.")
else:
    total_cost = venue + equipment + catering + transport + certificates
    remaining = max(0, total_cost - sponsorship)
    print(f"Total event cost: Rs.{total_cost:.2f}")
    print(f"Funding required after sponsorship: Rs.{remaining:.2f}")
    if remaining == 0:
        print("Minimum registrations required: 0")
    elif fee == 0:
        print("Break-even impossible with a zero registration fee.")
    else:
        needed = int((remaining + fee - 0.01) // fee)
        print("Minimum registrations required:", needed)
