# Python Activity-Based Learning
# Case Study 14: Warehouse Inventory Reconciliation
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

n = int(input("Number of products: "))
if n <= 0:
    print("Enter at least one product.")
else:
    for i in range(n):
        name = input("Product name: ")
        opening = int(input("Opening stock: "))
        received = int(input("Received stock: "))
        dispatched = int(input("Dispatched stock: "))
        recorded = int(input("Recorded closing stock: "))
        values = [opening, received, dispatched, recorded]
        if min(values) < 0 or dispatched > opening + received:
            print("Invalid stock data for", name)
        else:
            expected = opening + received - dispatched
            discrepancy = recorded - expected
            replenish = max(0, 10 - recorded)
            print("Product:", name)
            print("Expected closing stock:", expected)
            print("Discrepancy (recorded - expected):", discrepancy)
            print("Replenishment to reach 10 units:", replenish)
