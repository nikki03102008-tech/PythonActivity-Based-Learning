# Python Activity-Based Learning
# Case Study 12: Attendance Recovery Computation
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

attended = int(input("Classes attended: "))
total = int(input("Total classes conducted: "))
target = 75
if total <= 0 or attended < 0 or attended > total:
    print("Invalid attendance data.")
else:
    current = attended / total * 100
    extra = 0
    while (attended + extra) / (total + extra) * 100 < target:
        extra += 1
    print(f"Current attendance: {current:.2f}%")
    print(f"Additional consecutive classes to attend: {extra}")
    print(f"Attendance after attending them: {(attended + extra)/(total + extra)*100:.2f}%")
