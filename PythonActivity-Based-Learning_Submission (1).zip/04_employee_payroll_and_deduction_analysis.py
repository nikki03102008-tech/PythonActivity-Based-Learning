# Python Activity-Based Learning
# Case Study 4: Employee Payroll and Deduction Analysis
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

name = input("Employee name: ")
basic = float(input("Basic pay: "))
allowances = float(input("Allowances: "))
overtime = float(input("Overtime pay: "))
incentives = float(input("Incentives: "))
if min(basic, allowances, overtime, incentives) < 0:
    print("Invalid input: pay values cannot be negative.")
else:
    gross = basic + allowances + overtime + incentives
    rate = 0.05 if gross > 30000 else 0.02
    deduction = gross * rate
    net = gross - deduction
    print("\n--- SALARY STATEMENT ---")
    print("Employee:", name)
    print(f"Gross salary: Rs.{gross:.2f}")
    print(f"Deduction ({rate*100:.0f}%): Rs.{deduction:.2f}")
    print(f"Net salary: Rs.{net:.2f}")
