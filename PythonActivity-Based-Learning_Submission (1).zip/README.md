# PythonActivity-Based-Learning

**Student:** Mandavilli Nikhil  
**NIAT ID:** N26V01A0436  
**NRI ID:** 26000772

This repository contains ten Python Activity-Based Learning case studies selected from the college-provided list.

## Contents
- `Python_Activity_Based_Learning_Report.pdf` — combined report.
- `NN_*.py` — individual Python source programs.
- `outputs/` — test input/output transcripts.
- `screenshots/` — formatted test evidence panels.

## How to run
1. Open an online Python compiler such as Programiz Online Python Compiler or Replit.
2. Open one `.py` file and paste its contents.
3. Run the program and enter the test input shown in the report.
4. Capture the compiler screen showing both entered input and resulting output.
5. Replace the illustrative evidence panels with your own genuine online-compiler screenshots before final submission.

All tariff, deduction, tax, and academic policy values are illustrative assumptions for programming practice, not real institutional or legal rules.
