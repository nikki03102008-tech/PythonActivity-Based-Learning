# Python Activity-Based Learning
# Case Study 3: Hospital Billing and Patient Classification
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

consult = float(input("Consultation charge: "))
diagnostic = float(input("Diagnostic charge: "))
treatment = float(input("Treatment charge: "))
age = int(input("Patient age: "))
if min(consult, diagnostic, treatment, age) < 0:
    print("Invalid input: values cannot be negative.")
else:
    subtotal = consult + diagnostic + treatment
    concession = subtotal * 0.10 if age >= 60 else 0
    total = subtotal - concession
    if total < 1000:
        category = "Basic"
    elif total <= 5000:
        category = "Moderate"
    else:
        category = "High"
    print(f"Subtotal: Rs.{subtotal:.2f}")
    print(f"Concession: Rs.{concession:.2f}")
    print(f"Final bill: Rs.{total:.2f}")
    print(f"Patient bill category: {category}")
