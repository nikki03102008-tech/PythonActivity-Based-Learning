# Python Activity-Based Learning
# Case Study 2: Progressive Electricity Billing
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

units = int(input("Enter units consumed: "))
if units < 0:
    print("Invalid input: units cannot be negative.")
else:
    if units <= 100:
        energy = units * 1.50
    elif units <= 200:
        energy = 150 + (units - 100) * 2.50
    else:
        energy = 400 + (units - 200) * 4.00
    fixed = 50
    surcharge = energy * 0.05 if units > 250 else 0
    total = energy + fixed + surcharge
    print(f"Energy charge: Rs.{energy:.2f}")
    print(f"Fixed charge: Rs.{fixed:.2f}")
    print(f"Surcharge: Rs.{surcharge:.2f}")
    print(f"Total bill: Rs.{total:.2f}")
