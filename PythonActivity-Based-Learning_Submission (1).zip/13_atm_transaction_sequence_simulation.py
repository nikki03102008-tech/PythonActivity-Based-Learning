# Python Activity-Based Learning
# Case Study 13: ATM Transaction Sequence Simulation
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

balance = float(input("Opening balance: "))
n = int(input("Number of transactions: "))
deposits = 0
withdrawals = 0
if balance < 0 or n < 0:
    print("Invalid opening balance or transaction count.")
else:
    for i in range(n):
        kind = input("Transaction type (D/W): ").upper()
        amount = float(input("Amount: "))
        if amount <= 0:
            print("Rejected: amount must be positive.")
        elif kind == "D":
            balance += amount
            deposits += 1
            print("Deposit successful.")
        elif kind == "W":
            if amount <= balance:
                balance -= amount
                withdrawals += 1
                print("Withdrawal successful.")
            else:
                print("Rejected: insufficient balance.")
        else:
            print("Rejected: invalid transaction type.")
    print(f"Final balance: Rs.{balance:.2f}")
    print("Successful deposits:", deposits)
    print("Successful withdrawals:", withdrawals)
