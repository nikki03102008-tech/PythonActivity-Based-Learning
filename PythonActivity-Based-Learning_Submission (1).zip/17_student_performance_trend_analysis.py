# Python Activity-Based Learning
# Case Study 17: Student Performance Trend Analysis
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

name = input("Student name: ")
subjects = ["Python", "Mathematics", "English"]
test1 = []
test2 = []
for subject in subjects:
    test1.append(int(input(f"{subject} - Assessment 1: ")))
for subject in subjects:
    test2.append(int(input(f"{subject} - Assessment 2: ")))
if any(mark < 0 or mark > 100 for mark in test1 + test2):
    print("Invalid input: marks must be between 0 and 100.")
else:
    total1 = sum(test1)
    total2 = sum(test2)
    change = total2 - total1
    weak = [subjects[i] for i in range(3) if test2[i] < 40]
    average = total2 / 3
    if average >= 75:
        category = "Good"
    elif average >= 50:
        category = "Average"
    else:
        category = "Needs Improvement"
    print("Student:", name)
    print("Assessment 1 total:", total1, "/ 300")
    print("Assessment 2 total:", total2, "/ 300")
    print("Change in total:", change)
    print("Subjects needing attention:", weak if weak else "None")
    print(f"Latest average: {average:.2f}")
    print("Performance:", category)
