# Python Activity-Based Learning
# Case Study 7: Retail Billing with Multiple Discount Rules
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

n = int(input("Number of products: "))
if n <= 0:
    print("Invalid input: enter at least one product.")
else:
    subtotal = 0
    valid = True
    for i in range(n):
        print(f"Product {i + 1}")
        name = input("Name: ")
        price = float(input("Unit price: "))
        quantity = int(input("Quantity: "))
        if price < 0 or quantity <= 0:
            print("Invalid product price or quantity.")
            valid = False
            break
        line_total = price * quantity
        subtotal += line_total
        print(f"{name} line total: Rs.{line_total:.2f}")
    if valid:
        discount = subtotal * 0.10 if subtotal >= 2000 else 0
        taxable = subtotal - discount
        tax = taxable * 0.05
        total = taxable + tax
        print(f"Subtotal: Rs.{subtotal:.2f}")
        print(f"Discount: Rs.{discount:.2f}")
        print(f"Tax: Rs.{tax:.2f}")
        print(f"Final amount: Rs.{total:.2f}")
