# Python Activity-Based Learning
# Case Study 11: Examination Result and Grace-Mark Validation
# Student: Mandavilli Nikhil | NIAT ID: N26V01A0436 | NRI ID: 26000772

marks = []
for i in range(3):
    mark = int(input(f"Enter marks for subject {i + 1} (0-100): "))
    marks.append(mark)
if any(mark < 0 or mark > 100 for mark in marks):
    print("Invalid input: marks must be between 0 and 100.")
else:
    below = [i for i in range(3) if marks[i] < 40]
    if len(below) == 1 and marks[below[0]] == 39:
        other_subjects_pass = all(marks[i] >= 40 for i in range(3) if i != below[0])
        if other_subjects_pass:
            marks[below[0]] += 1
            print("One grace mark applied.")
    total = sum(marks)
    percentage = total / 3
    result = "PASS" if all(mark >= 40 for mark in marks) else "FAIL"
    print("Final marks:", marks)
    print("Total:", total, "/ 300")
    print(f"Percentage: {percentage:.2f}%")
    print("Result:", result)
